__author__ = "Alon B.R."

from PygameBuiltins import buttons, particles, animations, utils

print("Welcome to the PygameBuiltins libarary 0.2.0")
